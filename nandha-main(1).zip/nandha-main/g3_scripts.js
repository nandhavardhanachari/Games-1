function launchGame(gameFile) {
    window.location.href = gameFile;
}